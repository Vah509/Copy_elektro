import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://elektroschit.com.ua',
  output: 'static',
  integrations: [
    sitemap({
      filter: (page) => !page.includes('/admin_509'),
    }),
  ],
});
