// src/data/tags-registry.ts
// ЄДИНЕ ДЖЕРЕЛО ІСТИНИ для типів, тегів та властивостей виконаних робіт.
//
// При додаванні нового значення — редагувати ТІЛЬКИ цей файл.
// config.ts автоматично будує enum-валідацію на основі цих ключів.

// ─── РОЗДІЛИ (types) ────────────────────────────────────────
// Відповідають розділам продукції на сайті.
export const TYPE_LABELS: Record<string, string> = {
  hrshch:             'ГРЩ / ВРЩ',
  dymovydalennia:     'Димовидалення',
  dvyhuny:            'Керування двигунами',
  shuz:               'ШУЗ',
  krm:                'КРМ',
  'zenitni-lihtari':  'Зенітні ліхтарі',
  ahro:               'Агро',
  plk:                'ПЛК',
  elektromontazh:     'Електромонтаж',
  'shafi-keruvannia': 'Шафи керування',
};

// ─── ТЕГИ (tags) ────────────────────────────────────────────
// Беруть участь у фільтрації на сторінці каталогу.
export const TAG_LABELS: Record<string, string> = {
  avr:                         'Шафа з АВР',
  'sylova-shafa':              'Силова шафа',
  'upravlinnia-osvitlenniiam': 'Управління освітленням',
};

// ─── ВЛАСТИВОСТІ (properties) ───────────────────────────────
// Інформаційні характеристики щита — відображаються на картці,
// але поки не беруть участь у фільтрації.
// В майбутньому можна легко додати фільтр по них.
export const PROPERTY_LABELS: Record<string, string> = {
  'pryamyi-pusk':              'Прямий пуск',
  'zirka-trykutnyk':           'Зірка-трикутник',
  'chastotnyy-peretvoryuvach': 'Частотний перетворювач',
  'kontrol-faz':               'Контроль фаз',
  'plavnyi-pusk':              'Плавний пуск',
  'avr-na-kontaktorakh':       'АВР на контакторах',
  'avr-na-peremykachakh':      'АВР на перемикачах',
  'try-vvody':                 'Три вводи',
};
